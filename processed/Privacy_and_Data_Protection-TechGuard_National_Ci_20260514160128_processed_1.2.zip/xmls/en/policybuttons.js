var PolicySuccessBoxButton =
  "<a href='#' onclick='ClosePolicyDialog(2); return false' style='display:block; position:absolute; right:20px; bottom:10px; width:40px; margin-bottom:0px;' class='themebutton' title='" +
  ContinueButton +
  "'><center><p class='title color-black' style='font-size: 20px; font-weight: normal; text-shadow:none; top: -13px; position: absolute;text-align: right; left: -70px;'>Continue</p><img id='answerbutton2' src='xmls/multimedia/images/next-icon.png' style='margin-right:0px'></center></a>";

var PolicyInvalidBoxButton =
  "<a href='#' onclick='ClosePolicyDialog(0); return false' style='display:block; position:absolute; right:20px; bottom:10px; width:40px; margin-bottom:0px;' class='themebutton' id='answerbutton2' title='" +
  ContinueButton +
  "'><center><p class='title color-black' style='font-size: 20px; font-weight: normal; text-shadow:none; top: -13px; position: absolute;text-align: right; left: -70px;'>Continue</p><img src='xmls/multimedia/images/next-icon.png' style='margin-right:0px'></center></a>";

var PolicyIncompleteBoxButton =
  "<a href='#' onclick='ClosePolicyDialog(0); return false' style='display:block; position:absolute; right:20px; bottom:10px; width:40px; margin-bottom:0px;' class='themebutton' id='answerbutton2' title='" +
  ContinueButton +
  "'><center><p class='title color-black' style='font-size: 20px; font-weight: normal; text-shadow:none; top: -13px; position: absolute;text-align: right; left: -70px;'>Continue</p><img src='xmls/multimedia/images/next-icon.png' style='margin-right:0px'></center></a>";
