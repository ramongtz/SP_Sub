///////////// GLOBAL VARIABLES /////////////////////////////////////

// Course Name, Code and Description
var COURSE_NAME = " Privacy and Data Protection";
var COURSE_CODE = " P-101-PB-01-EN";

var DISPLAY_CERTIFICATE = false;
var DISPLAY_CERTIFICATE_FOR_COMPLETED_COURSE = false;
var DISPLAY_SCORE_ON_CERTIFICATE = false;

/////////////Set Page Title//////////////////////////////
function SetPageTitle()
{
	document.title = COURSE_NAME;
}
SetPageTitle();

///////////// END /////////////////////////////////////